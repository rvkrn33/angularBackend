package com.city.CityServiceApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CityServiceAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CityServiceAppApplication.class, args);
	}

}
