package com.city.CityServiceApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CityServiceAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
