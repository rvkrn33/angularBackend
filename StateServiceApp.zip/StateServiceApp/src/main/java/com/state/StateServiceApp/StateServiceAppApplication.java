package com.state.StateServiceApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StateServiceAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(StateServiceAppApplication.class, args);
	}

}
